import 'package:flutter/material.dart';

class ProfileCard extends StatelessWidget {
  const ProfileCard({
    Key? key, // Cambia "super.key" por "Key? key"
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: GestureDetector(
          onTap: () {
            showDialog(
              context: context,
              builder: (BuildContext context) {
                return Dialog(
                  backgroundColor: Colors.transparent,
                  elevation: 0.0,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(175.0),
                    child: const Image(
                      image: AssetImage('assets/rick.jpg'),
                      width: 275.0,
                      height: 275.0,
                      fit: BoxFit.cover,
                    ),
                  ),
                );
              },
            );
          },
          child: ClipRRect(
            borderRadius: BorderRadius.circular(25.0),
            child: const Image(
              image: AssetImage('assets/rick.jpg'),
              width: 50.0,
              height: 50.0,
              fit: BoxFit.cover,
            ),
          ),
        ),
        title: const Text('Rick Grimes'),
        subtitle: const Text('Masculino - 32 años'),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Align(
              alignment: Alignment.topRight,
              child: Text(
                'Paciente',
                style: TextStyle(
                  fontSize: 12.0,
                  color: Colors.grey,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
