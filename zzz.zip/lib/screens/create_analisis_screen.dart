import 'package:flutter/material.dart';
import 'package:helloworld/models/models.dart';
import 'package:helloworld/widgets/widgets.dart';

class CreateAScreen extends StatelessWidget {
  const CreateAScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          color: Colors.white,
        ),
        child: SafeArea(
          child: Container(
            decoration: const BoxDecoration(
              color: Colors.white,
            ),
            child: Column(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.grey[200],
                    ),
                    child: ListView(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16.0,
                        vertical: 18.0,
                      ),
                      children: [
                        const Text(
                          'Registro de Analisis',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 18.0,
                            fontWeight: FontWeight.w300,
                            color: Colors.black,
                          ),
                        ),
                        const SizedBox(height: 20.0),
                        const _BuildForm()
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _BuildForm extends StatefulWidget {
  const _BuildForm({
    Key? key,
  }) : super(key: key);

  @override
  State<_BuildForm> createState() => _BuildFormState();
}

class _BuildFormState extends State<_BuildForm> {
  final formKey = GlobalKey<FormState>();
  final List<String> bloodTypes = [
    'O+',
    'O-',
    'A+',
    'A-',
    'B+',
    'B-',
    'AB+',
    'AB-'
  ];
  Analisis analisis = Analisis(
      descripcion: 'Análisis de sangre para evaluar infección',
      motivo: 'Dolor de cabeza y fiebre persistente',
      fecha: DateTime(27, 07, 2022, 0, 0),
      hora: const TimeOfDay(hour: 21, minute: 30),
      emergenciaId: 1);
  String password = '';

  /* Emergency({
    this.id,
    this.motivo,
    this.gravedad,
    this.observacion,
    required this.estado,
    required this.fecha,
    required this.hora,
    this.detalleFin,
    this.diagnostico,
    required this.userId,
    this.nameUser,
    required this.medicoId,
  }); */

  @override
  Widget build(BuildContext context) {
    return Form(
      key: formKey,
      child: Column(
        children: [
          MyTextArea(
            labelText: 'Descripción del Analisis',
            maxLines: null,
            onChanged: (value) {
              setState(() {
                analisis.descripcion = value;
              });
            },
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Este campo es requerido';
              }
              return null; // Sin errores de validación
            },
            value: analisis.descripcion,
          ),
          const SizedBox(
            height: 10,
          ),
          MyTextArea(
            labelText: 'Motivo',
            maxLines: null,
            onChanged: (value) {
              setState(() {
                analisis.motivo = value;
              });
            },
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Este campo es requerido';
              }
              return null; // Sin errores de validación
            },
            value: analisis.motivo,
          ),
          const SizedBox(
            height: 10,
          ),
          MyDateField(
            labelText: 'Fecha de Emergencia',
            selectedDate: analisis.fecha,
            onChanged: (value) {
              setState(() {
                analisis.fecha =
                    value!; // Actualiza el nombre del usuario con el nuevo valor ingresado
              });
            },
            validator: (value) {
              if (value == null) {
                return 'Este campo es requerido';
              }
              // Aquí puedes agregar una validación de formato de fecha si lo deseas
              return null; // Sin errores de validación
            },
          ),
          const SizedBox(
            height: 10,
          ),
          MyTimeField(
            labelText: 'Hora',
            selectedTime: analisis.hora,
            onChanged: (value) {
              setState(() {
                analisis.hora = value!;
              });
            },
          ),
          const SizedBox(height: 10),
          ElevatedButton(
            onPressed: () async {
              /* if (formKey.currentState!.validate() && !userService.isLoading) {
                await userService.createUsuario(user, password, user.group!);
              }
              if (context.mounted) {
                Navigator.pop(context);
              } */
            },
            child: const Text('Guardar cambios'),
          ),
        ],
      ),
    );
  }
}
