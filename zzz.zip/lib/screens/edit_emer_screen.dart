import 'package:flutter/material.dart';
import 'package:helloworld/models/models.dart';
import 'package:helloworld/widgets/widgets.dart';

class EditEScreen extends StatelessWidget {
  const EditEScreen({super.key, required this.emergency});
  final Emergency emergency;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          color: Colors.white,
        ),
        child: SafeArea(
          child: Container(
            decoration: const BoxDecoration(
              color: Colors.white,
            ),
            child: Column(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.grey[200],
                    ),
                    child: ListView(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16.0,
                        vertical: 18.0,
                      ),
                      children: [
                        const Text(
                          'Registro de Emergencia',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 18.0,
                            fontWeight: FontWeight.w300,
                            color: Colors.black,
                          ),
                        ),
                        const SizedBox(height: 20.0),
                        _BuildForm(emergency: emergency)
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _BuildForm extends StatefulWidget {
  const _BuildForm({
    Key? key,
    required this.emergency,
  }) : super(key: key);

  final Emergency emergency;

  @override
  State<_BuildForm> createState() => _BuildFormState();
}

class _BuildFormState extends State<_BuildForm> {
  final formKey = GlobalKey<FormState>();
  final List<String> bloodTypes = [
    'O+',
    'O-',
    'A+',
    'A-',
    'B+',
    'B-',
    'AB+',
    'AB-'
  ];
  User user = User(name: '', email: '');
  String password = '';

  @override
  Widget build(BuildContext context) {
    return Form(
      key: formKey,
      child: Column(
        children: [
          MyTextArea(
            labelText: 'Motivo',
            maxLines: null,
            onChanged: (value) {
              setState(() {
                widget.emergency.motivo = value;
              });
            },
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Este campo es requerido';
              }
              return null; // Sin errores de validación
            },
            value: widget.emergency.motivo,
          ),
          const SizedBox(
            height: 10,
          ),
          MyDropdown<String>(
            labelText: 'Gravedad',
            items: [
              const DropdownMenuItem<String>(
                value: 'Baja',
                child: Text('Baja'),
              ),
              const DropdownMenuItem<String>(
                value: 'Media',
                child: Text('Media'),
              ),
              const DropdownMenuItem<String>(
                value: 'Alta',
                child: Text('Alta'),
              ),
            ],
            value: widget.emergency.gravedad,
            onChanged: (value) {
              setState(() {
                widget.emergency.gravedad = value;
              });
            },
          ),
          const SizedBox(
            height: 10,
          ),
          MyDateField(
            labelText: 'Fecha de Emergencia',
            selectedDate: widget.emergency.fecha,
            onChanged: (value) {
              setState(() {
                widget.emergency.fecha =
                    value!; // Actualiza el nombre del usuario con el nuevo valor ingresado
              });
            },
            validator: (value) {
              if (value == null) {
                return 'Este campo es requerido';
              }
              // Aquí puedes agregar una validación de formato de fecha si lo deseas
              return null; // Sin errores de validación
            },
          ),
          const SizedBox(
            height: 10,
          ),
          MyTimeField(
            labelText: 'Hora',
            selectedTime: widget.emergency.hora,
            onChanged: (value) {
              setState(() {
                widget.emergency.hora = value!;
              });
            },
          ),
          const SizedBox(
            height: 10,
          ),
          MyTextArea(
            labelText: 'Observación',
            maxLines: null,
            onChanged: (value) {
              setState(() {
                widget.emergency.observacion = value;
              });
            },
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Este campo es requerido';
              }
              return null; // Sin errores de validación
            },
            value: widget.emergency.observacion,
          ),
          const SizedBox(height: 10),
          ElevatedButton(
            onPressed: () async {},
            child: const Text('Guardar cambios'),
          ),
        ],
      ),
    );
  }
}
